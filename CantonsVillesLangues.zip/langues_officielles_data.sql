/*  Titre   : cantons_has_languages_data.sql
    Auteur  : Raphaël Favre
    Version : 2.0
*/
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (3,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (2,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (1,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (5,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (6,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (4,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (4,2);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (7,2);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (7,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (8,2);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (9,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (10,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (10,4);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (10,3);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (11,2);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (11,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (27,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (12,2);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (13,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (14,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (16,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (17,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (19,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (18,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (21,3);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (20,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (22,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (24,2);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (24,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (23,2);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (25,1);
INSERT INTO cantons_has_languages(cantons_id,languages_id) VALUES (26,1);
