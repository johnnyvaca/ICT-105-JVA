/*  Titre   : langues_data.sql
    Auteur  : Raphaël Favre
    Version : 1.0
*/
INSERT INTO languages(id,name) VALUES (1,'allemand');
INSERT INTO languages(id,name) VALUES (2,'français');
INSERT INTO languages(id,name) VALUES (3,'italien');
INSERT INTO languages(id,name) VALUES (4,'romanche');
